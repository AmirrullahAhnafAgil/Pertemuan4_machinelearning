import csv

# Fungsi untuk membaca data dari file CSV
def baca_csv(nama_file):
    data = []
    with open(nama_file, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    return data

# Fungsi untuk menampilkan informasi statistik
def tampilkan_statistik(data):
    penggunaan_listrik = [float(row['Penggunaan_Listrik']) for row in data]

    print("Statistik Penggunaan Listrik:")
    print("  Rata-rata: {:.2f} kWh".format(sum(penggunaan_listrik) / len(penggunaan_listrik)))
    print("  Minimum: {:.2f} kWh".format(min(penggunaan_listrik)))
    print("  Maksimum: {:.2f} kWh".format(max(penggunaan_listrik)))

# Main program
def main():
    # Baca data dari file CSV
    nama_file = 'data.csv'
    data = baca_csv(nama_file)

    # Tampilkan informasi statistik
    tampilkan_statistik(data)

if __name__ == "__main__":
    main()
